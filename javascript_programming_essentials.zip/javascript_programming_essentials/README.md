https://www.coursera.org/learn/javascript-programming-essentials

Installed npm libraries:

- Axios
