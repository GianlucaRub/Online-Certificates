const Footer = () => {
  return (
    <>
      <footer>
        <p>Event Planner Organization. All rights reserved.</p>
      </footer>
    </>
  );
};

export default Footer;
