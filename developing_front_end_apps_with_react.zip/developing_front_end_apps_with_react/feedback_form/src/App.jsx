import React from 'react'
import './App.css'
import FeedbackForm from './Components/FeedbackForm'

function App() {
  return (
   <>
 <FeedbackForm/>
   </>
  )
}

export default App