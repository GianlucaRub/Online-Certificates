import ContentRating from "./Components/ContentRating"

function App() {
  return (
   <>
  <ContentRating/>
   </>
  )
}

export default App
